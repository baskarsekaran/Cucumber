package wallethub;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double a = 0.02;
		double b = 0.03;
		double c = b - a;
		
		System.out.println(c);

	}

}
